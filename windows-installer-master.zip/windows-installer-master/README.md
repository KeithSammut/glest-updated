
========================================================================================

ARCHIVED
========
This project is no longer maintained. If you would like to contact about this, please find us on **[Discord](https://discord.gg/es3EyBB)**.

========================================================================================

# Glest

**Official Website: https://glest.io**

The Glest installer for Windows

The source code of the executable can be found here: https://github.com/Glest/windows-installer-src/
